export const EXT_MAP: Record<string, string> = {
  js: 'js', javascript: 'js',
  ts: 'ts', typescript: 'ts',
  jsx: 'jsx', tsx: 'tsx',
  md: 'md', markdown: 'md',
  html: 'html', css: 'css', scss: 'scss',
  py: 'py', python: 'py',
  json: 'json',
  sh: 'sh', bash: 'sh', shell: 'sh',
  sql: 'sql', yaml: 'yml', yml: 'yml', xml: 'xml',
  c: 'c', cpp: 'cpp', java: 'java', rs: 'rs', go: 'go',
};

// Default filename stems per language when none can be detected
const DEFAULT_NAMES: Record<string, string> = {
  js: 'index', javascript: 'index',
  ts: 'index', typescript: 'index',
  jsx: 'App', tsx: 'App',
  html: 'index', css: 'styles', scss: 'styles',
  py: 'main', python: 'main',
  json: 'data',
  sh: 'script', bash: 'script', shell: 'script',
  sql: 'query',
  md: 'README', markdown: 'README',
  yaml: 'config', yml: 'config',
  xml: 'config',
  go: 'main', rs: 'main', java: 'Main', c: 'main', cpp: 'main',
};

export interface CodeBlock {
  id: string;
  lang: string;
  ext: string;
  code: string;
  suggestedFilename: string; // always populated — from context or auto-generated
}

export interface ParsedContent {
  parts: Array<{ type: 'text'; content: string } | { type: 'code'; block: CodeBlock }>;
}

let blockCounter = 0;

/**
 * Looks backward through the text just before a code fence to find a filename.
 * Matches patterns like:
 *   `index.html`, **styles.css**, `src/App.tsx`, "script.py", (script.js), etc.
 * Also matches plain mentions like "index.html:" at end of a line.
 */
function detectFilename(textBefore: string, ext: string): string | null {
  // Grab the last ~300 chars before the fence to keep it local
  const tail = textBefore.slice(-300);

  // Pattern: a filename with a known extension, possibly wrapped in backticks/quotes/parens/bold
  const filenamePattern = /(?:^|[\s(`'"*([])([a-zA-Z0-9_\-./]+\.[a-zA-Z0-9]{1,6})(?:[)`'"*\]\s:,]|$)/gm;
  const matches: string[] = [];
  let m: RegExpExecArray | null;
  while ((m = filenamePattern.exec(tail)) !== null) {
    matches.push(m[1]);
  }

  if (!matches.length) return null;

  // Prefer the last match closest to the fence
  // Filter to only filenames that share the same extension or are plausible
  const extNorm = ext.toLowerCase();
  const sameExt = matches.filter(f => f.toLowerCase().endsWith(`.${extNorm}`));
  if (sameExt.length) return sameExt[sameExt.length - 1];

  // If none match ext exactly, return the last match that looks like a real filename (has a dot)
  const withDot = matches.filter(f => f.includes('.') && !f.startsWith('.'));
  if (withDot.length) return withDot[withDot.length - 1];

  return null;
}

export function parseContent(raw: string): ParsedContent {
  const parts: ParsedContent['parts'] = [];
  const regex = /```(\w*)\n?([\s\S]*?)```/g;
  let lastIndex = 0;
  let match: RegExpExecArray | null;

  while ((match = regex.exec(raw)) !== null) {
    const textBefore = raw.slice(lastIndex, match.index);
    if (textBefore) {
      parts.push({ type: 'text', content: textBefore });
    }

    const lang = (match[1] || 'text').toLowerCase();
    const ext = EXT_MAP[lang] ?? lang;

    // Try to find a filename in the surrounding text
    const detected = detectFilename(raw.slice(0, match.index), ext);
    const defaultStem = DEFAULT_NAMES[lang] ?? 'file';
    const suggestedFilename = detected ?? `${defaultStem}.${ext}`;

    parts.push({
      type: 'code',
      block: {
        id: `cb_${++blockCounter}`,
        lang,
        ext,
        code: match[2].trimEnd(),
        suggestedFilename,
      },
    });
    lastIndex = regex.lastIndex;
  }

  if (lastIndex < raw.length) {
    parts.push({ type: 'text', content: raw.slice(lastIndex) });
  }

  return { parts };
}

/** Very lightweight inline markdown → HTML (no DOMParser needed) */
export function renderInlineMarkdown(text: string): string {
  return text
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
    .replace(/\*(.+?)\*/g, '<em>$1</em>')
    .replace(/__(.+?)__/g, '<strong>$1</strong>')
    .replace(/_(.+?)_/g, '<em>$1</em>')
    .replace(/`([^`]+)`/g, '<code>$1</code>');
}

export function renderTextBlock(text: string): string {
  let html = text
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    // headings
    .replace(/^### (.+)$/gm, '<h3>$1</h3>')
    .replace(/^## (.+)$/gm, '<h2>$1</h2>')
    .replace(/^# (.+)$/gm, '<h1>$1</h1>')
    // hr
    .replace(/^---$/gm, '<hr />')
    // blockquote
    .replace(/^> (.+)$/gm, '<blockquote>$1</blockquote>')
    // bold/italic
    .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
    .replace(/\*(.+?)\*/g, '<em>$1</em>')
    .replace(/__(.+?)__/g, '<strong>$1</strong>')
    .replace(/_(.+?)_/g, '<em>$1</em>')
    // inline code
    .replace(/`([^`]+)`/g, '<code>$1</code>')
    // lists
    .replace(/^[\*\-] (.+)$/gm, '<li>$1</li>')
    .replace(/^\d+\. (.+)$/gm, '<li>$1</li>');

  // wrap consecutive <li> in <ul>
  html = html.replace(/(<li>[\s\S]*?<\/li>\n?)+/g, (m) => `<ul>${m}</ul>`);
  // paragraphs
  html = html.replace(/\n{2,}/g, '</p><p>');
  html = `<p>${html}</p>`;
  html = html.replace(/<p>\s*<\/p>/g, '');
  html = html.replace(/<p>(<(?:h[123]|ul|ol|div|blockquote|hr|pre))/g, '$1');
  html = html.replace(/(<\/(?:h[123]|ul|ol|div|blockquote|hr|pre)>)<\/p>/g, '$1');

  return html;
}
