// FILE: src/components/ChatPanel.tsx
import React, { useRef, useEffect, useState, useCallback, KeyboardEvent } from 'react';
import { MessageBubble } from './MessageBubble';
import { FileRegistryPanel } from './FileRegistryPanel';
import { StreamingPhaseIndicator } from './StreamingPhaseIndicator';
import { streamChat } from '../lib/ollama';
import { buildPlan, buildStepPrompt } from '../lib/planner';
import { updateRegistry, registryToSystemPrompt } from '../lib/fileRegistry';
import { extractCodeBlocksForRegistry } from '../lib/markdown';
import { PRESETS, getPreset, DEFAULT_PRESET_ID } from '../lib/presets';
import { readZipEntries } from '../lib/zip';
import {
  IconSend, IconStop, IconRotateCcw, IconX,
  IconPaperclip, IconFolder, IconHexagon,
  IconCode2, IconMessageSquare, IconSparkles,
  IconDownload,
} from './Icon';
import type { Panel, Message, StreamingPhase } from '../types';
import type { FileRegistry } from '../lib/fileRegistry';

interface Props {
  panel: Panel;
  models: string[];
  onUpdate: (id: string, patch: Partial<Panel>) => void;
  onClose: (id: string) => void;
  onSave: (panel: Panel) => void;
}

function langFromPath(path: string): string {
  const ext = path.split('.').pop()?.toLowerCase() ?? '';
  const map: Record<string, string> = {
    ts: 'ts', tsx: 'tsx', js: 'js', jsx: 'jsx',
    py: 'py', html: 'html', css: 'css', scss: 'scss',
    json: 'json', md: 'md', sh: 'sh', bash: 'bash',
    yaml: 'yaml', yml: 'yaml', xml: 'xml', sql: 'sql',
    go: 'go', rs: 'rs', java: 'java', c: 'c', cpp: 'cpp',
  };
  return map[ext] ?? ext ?? 'text';
}

const PRESET_ICONS: Record<string, React.ReactNode> = {
  code:     <IconCode2 size={12} />,
  chatbot:  <IconMessageSquare size={12} />,
  creative: <IconSparkles size={12} />,
};

/** Serialises the full conversation to a Markdown string for export. */
function exportChatAsMarkdown(panel: Panel): string {
  const date = new Date().toISOString().replace('T', ' ').slice(0, 19);
  const lines: string[] = [
    `# Chat Log — ${panel.title}`,
    ``,
    `**Model:** ${panel.model || 'unknown'}  `,
    `**Preset:** ${panel.preset || 'code'}  `,
    `**Exported:** ${date}  `,
    ``,
    `---`,
    ``,
  ];

  for (const msg of panel.messages) {
    const role = msg.role === 'user' ? '### You' : '### Assistant';
    lines.push(role, '', msg.content, '', '---', '');
  }

  return lines.join('\n');
}

export function ChatPanel({ panel, models, onUpdate, onClose, onSave }: Props) {
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const dirInputRef = useRef<HTMLInputElement>(null);
  const abortRef = useRef<AbortController | null>(null);
  const [inputValue, setInputValue] = useState('');

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [panel.messages, panel.streamingContent]);

  useEffect(() => {
    if (!panel.streaming) inputRef.current?.focus();
  }, [panel.streaming]);

  // ── Export chat log ───────────────────────────────────────────────────────
  function handleExportLog() {
    const md = exportChatAsMarkdown(panel);
    const blob = new Blob([md], { type: 'text/markdown' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    const slug = panel.title.replace(/[^a-z0-9]/gi, '_').toLowerCase() || 'chat';
    a.download = `${slug}_log.md`;
    a.click();
    URL.revokeObjectURL(a.href);
  }

  // ── Main send — multi-step orchestrator ───────────────────────────────────
  const handleSend = useCallback(async () => {
    const text = inputValue.trim();
    if (!text || panel.streaming) return;
    setInputValue('');

    const userMsg: Message = { role: 'user', content: text };
    const updatedMessages = [...panel.messages, userMsg];
    const snapshotRegistry: FileRegistry = new Map(panel.fileRegistry);

    onUpdate(panel.id, {
      messages: updatedMessages,
      streaming: true,
      streamingContent: '',
      prevRegistry: snapshotRegistry,
      streamingPhase: { label: 'Planning…', stepIndex: 0, totalSteps: 0 },
    });

    const abort = new AbortController();
    abortRef.current = abort;

    const preset = getPreset(panel.preset ?? DEFAULT_PRESET_ID);
    const isCodePreset = (panel.preset ?? DEFAULT_PRESET_ID) === 'code';

    // ── Non-code presets: single straight-through request ─────────────────
    if (!isCodePreset) {
      const systemPrompt = preset.systemPrompt + registryToSystemPrompt(panel.fileRegistry);
      let accumulated = '';
      try {
        const gen = streamChat(panel.model || models[0] || 'llama3', updatedMessages, systemPrompt, abort.signal);
        for await (const chunk of gen) {
          accumulated += chunk;
          onUpdate(panel.id, { streamingContent: accumulated, streamingPhase: null });
        }
        await finaliseResponse(accumulated, updatedMessages, snapshotRegistry, panel.fileRegistry);
      } catch (err) {
        handleError(err, updatedMessages);
      }
      return;
    }

    // ── Code preset: plan → step 1 → step 2 → … ──────────────────────────
    try {
      // Phase 0: planning
      const plan = await buildPlan(
        text,
        panel.messages,
        panel.model || models[0] || 'llama3',
        abort.signal,
      );

      const totalSteps = plan.steps.length;

      // Simple request — single pass, no batching UI
      if (!plan.isComplex) {
        onUpdate(panel.id, {
          streamingPhase: { label: 'Writing…', stepIndex: 1, totalSteps: 1 },
        });
        const systemPrompt = buildStepPrompt(
          preset.systemPrompt + registryToSystemPrompt(panel.fileRegistry),
          plan,
          0,
          [],
        );
        let accumulated = '';
        const gen = streamChat(panel.model || models[0] || 'llama3', updatedMessages, systemPrompt, abort.signal);
        for await (const chunk of gen) {
          accumulated += chunk;
          onUpdate(panel.id, { streamingContent: accumulated });
        }
        await finaliseResponse(accumulated, updatedMessages, snapshotRegistry, panel.fileRegistry);
        return;
      }

      // Complex request — stream each step, concatenate into one assistant message
      let combinedContent = '';
      let currentRegistry = panel.fileRegistry;
      const alreadyWritten: string[] = [];

      for (let si = 0; si < totalSteps; si++) {
        const step = plan.steps[si];

        // Label matches Claude's own "Step N of M — description" style
        const phaseLabel = `Step ${si + 1} of ${totalSteps} — ${step.label}`;

        onUpdate(panel.id, {
          streamingPhase: {
            label: phaseLabel,
            stepIndex: si + 1,
            totalSteps,
          },
        });

        const systemPrompt = buildStepPrompt(
          preset.systemPrompt + registryToSystemPrompt(currentRegistry),
          plan,
          si,
          alreadyWritten,
        );

        // From step 2 onwards, inject a brief assistant context message so the
        // model knows what it has already written and can stay consistent.
        const contextMessages: Message[] = si === 0
          ? updatedMessages
          : [
              ...updatedMessages,
              {
                role: 'assistant' as const,
                content: `[Steps 1–${si} complete. Files written: ${alreadyWritten.join(', ')}. Continuing with step ${si + 1}.]`,
              },
            ];

        let stepContent = '';
        const gen = streamChat(
          panel.model || models[0] || 'llama3',
          contextMessages,
          systemPrompt,
          abort.signal,
        );

        for await (const token of gen) {
          stepContent += token;
          onUpdate(panel.id, {
            streamingContent: combinedContent + stepContent,
          });
        }

        // Update registry with files from this step
        const newBlocks = extractCodeBlocksForRegistry(stepContent);
        currentRegistry = updateRegistry(currentRegistry, newBlocks, updatedMessages.length);
        for (const b of newBlocks) alreadyWritten.push(b.path);

        // Invisible separator between steps in the combined output
        const separator = si < totalSteps - 1
          ? `\n\n<!-- step-break: ${si + 1}/${totalSteps} -->\n\n`
          : '';
        combinedContent += stepContent + separator;
      }

      await finaliseResponse(combinedContent, updatedMessages, snapshotRegistry, panel.fileRegistry);

    } catch (err) {
      handleError(err, updatedMessages);
    }

    // ── Inner helpers ──────────────────────────────────────────────────────

    async function finaliseResponse(
      content: string,
      msgs: Message[],
      snapReg: FileRegistry,
      baseReg: FileRegistry,
    ) {
      const assistantMsg: Message = { role: 'assistant', content };
      const finalMessages = [...msgs, assistantMsg];
      const newBlocks = extractCodeBlocksForRegistry(content);
      const updatedRegistry = updateRegistry(baseReg, newBlocks, finalMessages.length - 1);

      onUpdate(panel.id, {
        messages: finalMessages,
        streaming: false,
        streamingContent: '',
        fileRegistry: updatedRegistry,
        prevRegistry: snapReg,
        streamingPhase: null,
      });
      onSave({
        ...panel,
        messages: finalMessages,
        fileRegistry: updatedRegistry,
        prevRegistry: snapReg,
        streamingPhase: null,
      });
    }

    function handleError(err: unknown, msgs: Message[]) {
      if ((err as Error)?.name === 'AbortError') {
        const content = panel.streamingContent;
        if (content) {
          const assistantMsg: Message = { role: 'assistant', content: content + '\n\n_[stopped]_' };
          const finalMessages = [...msgs, assistantMsg];
          const newBlocks = extractCodeBlocksForRegistry(content);
          const updatedRegistry = updateRegistry(panel.fileRegistry, newBlocks, finalMessages.length - 1);
          onUpdate(panel.id, { messages: finalMessages, streaming: false, streamingContent: '', fileRegistry: updatedRegistry, streamingPhase: null });
          onSave({ ...panel, messages: finalMessages, fileRegistry: updatedRegistry, streamingPhase: null });
        } else {
          onUpdate(panel.id, { streaming: false, streamingContent: '', streamingPhase: null });
        }
      } else {
        const errMsg: Message = {
          role: 'assistant',
          content: `Error: ${(err as Error).message}\n\nMake sure Ollama is running:\n\`\`\`bash\nOLLAMA_ORIGINS=* ollama serve\n\`\`\``,
        };
        onUpdate(panel.id, { messages: [...msgs, errMsg], streaming: false, streamingContent: '', streamingPhase: null });
      }
    }

  }, [inputValue, panel, models, onUpdate, onSave]);

  // ── File upload ───────────────────────────────────────────────────────────
  async function handleFileUpload(e: React.ChangeEvent<HTMLInputElement>) {
    const files = Array.from(e.target.files ?? []);
    if (!files.length) return;
    e.target.value = '';
    let added = 0;
    let reg = new Map(panel.fileRegistry);
    for (const file of files) {
      const uint8 = new Uint8Array(await file.arrayBuffer());
      if (file.name.endsWith('.zip')) {
        for (const entry of readZipEntries(uint8)) {
          reg = updateRegistry(reg, [{ path: entry.path, content: entry.content, lang: langFromPath(entry.path) }], 0);
          added++;
        }
      } else {
        const content = new TextDecoder('utf-8', { fatal: false }).decode(uint8);
        if (!content.includes('\0')) {
          reg = updateRegistry(reg, [{ path: file.name, content, lang: langFromPath(file.name) }], 0);
          added++;
        }
      }
    }
    const sysMsg: Message = { role: 'assistant', content: `_Uploaded ${added} file${added !== 1 ? 's' : ''} into the project registry._` };
    const finalMessages = [...panel.messages, sysMsg];
    onUpdate(panel.id, { messages: finalMessages, fileRegistry: reg });
    onSave({ ...panel, messages: finalMessages, fileRegistry: reg });
  }

  // ── Directory import ──────────────────────────────────────────────────────
  async function handleDirImport(e: React.ChangeEvent<HTMLInputElement>) {
    const files = Array.from(e.target.files ?? []);
    if (!files.length) return;
    e.target.value = '';
    let reg = new Map(panel.fileRegistry);
    let added = 0;
    for (const file of files) {
      const rel = (file as File & { webkitRelativePath?: string }).webkitRelativePath ?? file.name;
      const parts = rel.split('/');
      const cleanPath = parts.length > 1 ? parts.slice(1).join('/') : rel;
      if (/\.(png|jpg|jpeg|gif|webp|ico|woff|woff2|ttf|eot|mp4|mp3|pdf|zip|tar|gz|lock)$/.test(cleanPath)) continue;
      if (/node_modules|\.git|\.next|dist\/|build\//.test(cleanPath)) continue;
      const text = await file.text();
      if (text.includes('\0')) continue;
      reg = updateRegistry(reg, [{ path: cleanPath, content: text, lang: langFromPath(cleanPath) }], 0);
      added++;
    }
    const sysMsg: Message = { role: 'assistant', content: `_Imported ${added} file${added !== 1 ? 's' : ''} from directory into the project registry._` };
    const finalMessages = [...panel.messages, sysMsg];
    onUpdate(panel.id, { messages: finalMessages, fileRegistry: reg });
    onSave({ ...panel, messages: finalMessages, fileRegistry: reg });
  }

  function handleStop() { abortRef.current?.abort(); }

  function handleKeyDown(e: KeyboardEvent<HTMLTextAreaElement>) {
    if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleSend(); }
    const el = e.currentTarget;
    el.style.height = 'auto';
    el.style.height = `${Math.min(el.scrollHeight, 120)}px`;
  }

  function handleInputChange(e: React.ChangeEvent<HTMLTextAreaElement>) {
    setInputValue(e.target.value);
    const el = e.target;
    el.style.height = 'auto';
    el.style.height = `${Math.min(el.scrollHeight, 120)}px`;
  }

  function handleClear() {
    onUpdate(panel.id, { messages: [], fileRegistry: new Map(), prevRegistry: new Map(), streamingPhase: null });
    onSave({ ...panel, messages: [], fileRegistry: new Map(), prevRegistry: new Map(), streamingPhase: null });
  }

  function handlePresetChange(id: string) {
    onUpdate(panel.id, { preset: id });
    onSave({ ...panel, preset: id });
  }

  const currentPreset = panel.preset ?? DEFAULT_PRESET_ID;
  const hasMessages = panel.messages.length > 0;

  return (
    <div className="chat-panel">
      <div className="panel-header">
        <input
          className="panel-title"
          value={panel.title}
          placeholder="Chat name..."
          onChange={e => onUpdate(panel.id, { title: e.target.value })}
          onBlur={() => onSave(panel)}
        />
        <select
          className="model-select"
          value={panel.model}
          onChange={e => onUpdate(panel.id, { model: e.target.value })}
        >
          {models.length === 0
            ? <option value="">No models</option>
            : models.map(m => <option key={m} value={m}>{m}</option>)
          }
        </select>
        <div className="preset-tabs">
          {PRESETS.map(p => (
            <button
              key={p.id}
              className={`preset-tab${currentPreset === p.id ? ' active' : ''}`}
              onClick={() => handlePresetChange(p.id)}
              title={p.label}
            >
              {PRESET_ICONS[p.id]} {p.label}
            </button>
          ))}
        </div>
        {hasMessages && (
          <button
            className="panel-btn"
            onClick={handleExportLog}
            title="Export chat log as Markdown"
          >
            <IconDownload size={13} />
          </button>
        )}
        <button className="panel-btn" onClick={handleClear} title="Clear messages">
          <IconRotateCcw size={13} />
        </button>
        <button className="panel-btn close" onClick={() => onClose(panel.id)} title="Close panel">
          <IconX size={13} />
        </button>
      </div>

      <div className="messages">
        {!hasMessages && !panel.streaming ? (
          <div className="empty-state">
            <div className="empty-state-icon"><IconHexagon size={52} /></div>
            <h3>Ready</h3>
            <p>Ask me to write code, generate docs, or debug anything.</p>
          </div>
        ) : (
          <>
            {panel.messages.map((msg, i) => (
              <MessageBubble
                key={i}
                message={msg}
                withDownload={true}
                prevRegistry={panel.prevRegistry}
                currentRegistry={panel.fileRegistry}
                model={panel.model}
              />
            ))}
            {panel.streaming && (
              panel.streamingPhase && !panel.streamingContent ? (
                <div className="thinking">
                  <StreamingPhaseIndicator phase={panel.streamingPhase} />
                </div>
              ) : panel.streamingContent ? (
                <div className="streaming-wrap">
                  {panel.streamingPhase && (
                    <div className="streaming-phase-overlay">
                      <StreamingPhaseIndicator phase={panel.streamingPhase} />
                    </div>
                  )}
                  <MessageBubble
                    message={{ role: 'assistant', content: panel.streamingContent }}
                    withDownload={false}
                    prevRegistry={panel.prevRegistry}
                    currentRegistry={panel.fileRegistry}
                    model={panel.model}
                  />
                </div>
              ) : (
                <div className="thinking">
                  <div className="thinking-dots"><span /><span /><span /></div>
                  <span>thinking...</span>
                </div>
              )
            )}
          </>
        )}
        <div ref={messagesEndRef} />
      </div>

      <FileRegistryPanel registry={panel.fileRegistry} chatTitle={panel.title} />

      <div className="panel-input">
        <div className="input-row">
          <input ref={fileInputRef} type="file" multiple accept="*/*" style={{ display: 'none' }} onChange={handleFileUpload} />
          <input ref={dirInputRef} type="file"
            // @ts-ignore
            webkitdirectory="" multiple style={{ display: 'none' }} onChange={handleDirImport} />
          <div className="input-actions">
            <button className="input-action-btn" onClick={() => fileInputRef.current?.click()} title="Upload files or zip" disabled={panel.streaming}>
              <IconPaperclip size={14} />
            </button>
            <button className="input-action-btn" onClick={() => dirInputRef.current?.click()} title="Import project directory" disabled={panel.streaming}>
              <IconFolder size={14} />
            </button>
          </div>
          <textarea
            ref={inputRef}
            className="msg-input"
            rows={1}
            placeholder="Ask anything… (Shift+Enter for newline)"
            value={inputValue}
            onChange={handleInputChange}
            onKeyDown={handleKeyDown}
            disabled={panel.streaming}
          />
          {panel.streaming ? (
            <button className="send-btn stop" onClick={handleStop} title="Stop generation">
              <IconStop size={14} />
            </button>
          ) : (
            <button className="send-btn" onClick={handleSend} disabled={!inputValue.trim()}>
              <IconSend size={14} />
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
