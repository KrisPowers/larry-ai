// FILE: src/lib/deepPlanner.ts
/**
 * deepPlanner.ts — Two-phase orchestration engine for the Code-Planning preset.
 *
 * Phase 1: Ask the model to produce a thorough, atomic checklist of steps.
 *          Each step names exactly one file, its full purpose, what it must
 *          import, and what it must export. No code is written here.
 *
 * Phase 2: Execute each step as an independent streamChat call using the
 *          standard Code preset rules, with file-registry context injected
 *          so the model knows what already exists to import from.
 *
 * Smaller models stay within their capability budget because each request
 * is narrow: "write THIS file, it must do THIS, it can import from THESE."
 */

import { chatOnce } from './ollama';
import type { Message } from '../types';

// ─────────────────────────────────────────────────────────────────────────────
// Types
// ─────────────────────────────────────────────────────────────────────────────

/** One atomic unit of work produced by the deep planner. */
export interface DeepStep {
  /** 1-based index */
  stepNumber: number;
  /** Short label for the UI, e.g. "src/lib/router.ts" */
  label: string;
  /** Full relative path from project root */
  filePath: string;
  /** What this file is responsible for — detailed paragraph */
  purpose: string;
  /** Paths this file must import from (already-written files or npm packages) */
  imports: string[];
  /** Names/shapes this file must export for other files to consume */
  exports: string[];
  /** True for package.json, tsconfig, .gitignore, README */
  isSupport: boolean;
}

/** The full deep plan returned after Phase 1. */
export interface DeepPlan {
  /** One-paragraph description of the overall project */
  projectSummary: string;
  steps: DeepStep[];
}

// ─────────────────────────────────────────────────────────────────────────────
// Phase 1 — planning prompt
// ─────────────────────────────────────────────────────────────────────────────

const DEEP_PLANNER_SYSTEM = `You are a senior software architect. Your ONLY job is to
analyse a coding request and produce a thorough, atomic implementation checklist.

You must respond with ONLY valid JSON — no markdown fences, no explanation, nothing else.

Return this exact shape:
{
  "projectSummary": "A concise but thorough paragraph describing what will be built, the architecture chosen, the key design decisions, and why.",
  "steps": [
    {
      "stepNumber": 1,
      "filePath": "src/types/index.ts",
      "purpose": "Defines all shared TypeScript interfaces and types used across the project. Contains RequestHandler, Request, Response, NextFunction, RouteParams, Middleware, and RouterOptions interfaces. This file is imported by every other file so must be written first.",
      "imports": [],
      "exports": ["RequestHandler", "Request", "Response", "NextFunction", "RouteParams", "Middleware", "RouterOptions"],
      "isSupport": false
    }
  ]
}

Rules for producing the checklist:
- Every single file the project needs must appear as a step — source files AND support files.
- isSupport must be true for: package.json, tsconfig.json, .gitignore, README.md, .env.example, and any config that is not application logic.
- isSupport must be false for all actual source code.
- Order steps so that dependencies come before dependents: types → utilities → core logic → entry points → support files.
- The "purpose" field must be a thorough paragraph — not a one-liner. Describe: what the file does, its internal structure, every important function or class it implements, why it exists as a separate file, and what would break if it were missing.
- The "imports" field lists only files that must already exist when this file is written (relative paths or npm package names).
- The "exports" field lists every symbol other files will import from this file.
- Be exhaustive. A missing file = a broken project. Prefer more steps over fewer.
- Steps must be atomic: one file per step, no exceptions.
- Respond with JSON only. No other text. No markdown.`;

// ─────────────────────────────────────────────────────────────────────────────
// Phase 2 — per-step execution prompt
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Builds the injected task block appended to the Code preset system prompt
 * for a single implementation step.
 */
export function buildDeepStepPrompt(
  codeSystemPrompt: string,
  plan: DeepPlan,
  step: DeepStep,
  alreadyWritten: Array<{ path: string; exports: string[] }>,
): string {
  const total = plan.steps.length;

  const writtenContext = alreadyWritten.length > 0
    ? `\nFiles already written (available to import from):\n` +
      alreadyWritten.map(f =>
        `  ${f.path}${f.exports.length ? `  →  exports: ${f.exports.join(', ')}` : ''}`
      ).join('\n') + '\n'
    : '';

  const importsNote = step.imports.length > 0
    ? `\nThis file must import from:\n${step.imports.map(i => `  - ${i}`).join('\n')}\n`
    : '';

  const exportsNote = step.exports.length > 0
    ? `\nThis file must export:\n${step.exports.map(e => `  - ${e}`).join('\n')}\n`
    : '';

  return (
    codeSystemPrompt +
    `\n\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
    `STEP ${step.stepNumber} OF ${total}: ${step.filePath}\n` +
    `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
    `Project: ${plan.projectSummary}\n` +
    writtenContext +
    `\nYour task: Write ONLY this one file: ${step.filePath}\n` +
    `\nWhat it must do:\n${step.purpose}\n` +
    importsNote +
    exportsNote +
    `\nDo not write any other file. Do not write files from other steps.\n` +
    (step.stepNumber === total
      ? `This is the FINAL step. After the file, write the plain-text Overview.`
      : `This is NOT the final step. Do NOT write an Overview yet.`)
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// Exported API
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Phase 1: Sends the user's request to the model and returns a deep plan.
 * The model is instructed to produce only JSON — no streaming needed here.
 */
export async function buildDeepPlan(
  userMessage: string,
  conversationHistory: Message[],
  model: string,
  signal: AbortSignal,
): Promise<DeepPlan> {
  const raw = await chatOnce(
    model,
    [
      ...conversationHistory,
      { role: 'user', content: userMessage },
    ],
    DEEP_PLANNER_SYSTEM,
    signal,
  );

  // Strip markdown fences if the model wrapped JSON anyway
  const cleaned = raw
    .replace(/^```(?:json)?\s*/i, '')
    .replace(/\s*```\s*$/, '')
    .trim();

  let parsed: { projectSummary?: string; steps?: Partial<DeepStep>[] };
  try {
    parsed = JSON.parse(cleaned);
  } catch {
    // Fallback — return a minimal single-step plan so execution can still proceed
    return {
      projectSummary: userMessage,
      steps: [{
        stepNumber: 1,
        label: 'implementation',
        filePath: 'src/index.ts',
        purpose: userMessage,
        imports: [],
        exports: [],
        isSupport: false,
      }],
    };
  }

  const steps: DeepStep[] = (parsed.steps ?? []).map((s, i) => ({
    stepNumber: s.stepNumber ?? i + 1,
    label: s.filePath ?? `step-${i + 1}`,
    filePath: s.filePath ?? `src/step-${i + 1}.ts`,
    purpose: s.purpose ?? '',
    imports: s.imports ?? [],
    exports: s.exports ?? [],
    isSupport: s.isSupport ?? false,
  }));

  return {
    projectSummary: parsed.projectSummary ?? userMessage,
    steps,
  };
}
