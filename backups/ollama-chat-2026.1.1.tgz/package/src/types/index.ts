// FILE: src/types/index.ts
import type { FileRegistry } from '../lib/fileRegistry';

export interface Message {
  role: 'user' | 'assistant';
  content: string;
}

export interface ChatRecord {
  id: string;
  title: string;
  model: string;
  preset: string;
  messages: Message[];
  updatedAt: number;
  fileEntries?: Array<{ path: string; content: string; lang: string; updatedAt: number }>;
}

/**
 * Describes the current multi-phase streaming state shown in the UI.
 * Null when no multi-phase operation is in progress.
 */
export interface StreamingPhase {
  label: string;       // e.g. "Planning…" or "Writing batch 2 of 4"
  chunkIndex: number;  // 0 = planning, 1+ = implementation chunks
  totalChunks: number; // total implementation chunks (0 during planning)
}

export interface Panel {
  id: string;
  title: string;
  model: string;
  preset: string;
  messages: Message[];
  streaming: boolean;
  streamingContent: string;
  fileRegistry: FileRegistry;
  prevRegistry: FileRegistry;
  streamingPhase: StreamingPhase | null;
}

export type OllamaStatus = 'connecting' | 'online' | 'error';
