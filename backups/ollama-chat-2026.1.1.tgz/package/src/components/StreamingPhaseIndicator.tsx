// FILE: src/components/StreamingPhaseIndicator.tsx
import React from 'react';
import type { StreamingPhase } from '../types';

interface Props {
  phase: StreamingPhase;
}

/**
 * Shown in place of the typing indicator during multi-phase generation.
 * Displays which phase is active and a progress bar for implementation chunks.
 */
export function StreamingPhaseIndicator({ phase }: Props) {
  const isPlanning = phase.chunkIndex === 0;
  const progress = phase.totalChunks > 0
    ? Math.round(((phase.chunkIndex) / phase.totalChunks) * 100)
    : 0;

  return (
    <div className="phase-indicator">
      <div className="phase-indicator-top">
        <div className="thinking-dots">
          <span /><span /><span />
        </div>
        <span className="phase-label">{phase.label}</span>
      </div>

      {!isPlanning && phase.totalChunks > 1 && (
        <div className="phase-progress-wrap">
          <div className="phase-progress-bar">
            <div
              className="phase-progress-fill"
              style={{ width: `${progress}%` }}
            />
          </div>
          <span className="phase-progress-text">
            {phase.chunkIndex} / {phase.totalChunks} batches
          </span>
        </div>
      )}
    </div>
  );
}
