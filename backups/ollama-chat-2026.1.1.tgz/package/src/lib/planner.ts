// FILE: src/lib/planner.ts
import { chatOnce } from './ollama';
import type { Message } from '../types';

/** A single file the AI plans to produce. */
export interface PlannedFile {
  path: string;       // e.g. "src/lib/router.ts"
  description: string; // one sentence — what this file implements
  isSupport: boolean; // true for package.json, tsconfig, .gitignore, README
}

/** The full plan returned from the planning phase. */
export interface ProjectPlan {
  summary: string;       // 1–2 sentence project description
  files: PlannedFile[];
  chunks: PlannedFile[][]; // files grouped into sequential work batches
  isComplex: boolean;    // true when more than one chunk is needed
}

/**
 * Complexity threshold — if the plan has more than this many files,
 * we split into multiple requests.
 */
const CHUNK_SIZE = 4;

const PLANNER_SYSTEM = `You are a project planning assistant. Your only job is to
analyse a coding request and return a JSON plan. You must respond with ONLY
valid JSON — no markdown fences, no explanation, nothing else.

Return this exact shape:
{
  "summary": "one or two sentences describing what the project is",
  "files": [
    {
      "path": "src/lib/router.ts",
      "description": "Implements the core routing engine",
      "isSupport": false
    }
  ]
}

Rules:
- List every file the project needs: source files AND support files
  (package.json, tsconfig.json, .gitignore, README.md).
- Mark isSupport: true for package.json, tsconfig.json, .gitignore, README.md
  and any other config file that is not source code.
- Mark isSupport: false for all actual source code files.
- Use full relative paths from the project root.
- Order source files by dependency: types first, utilities next, core logic,
  then entry points last. Support files always at the end.
- Be complete. Do not omit files. A missing file = a broken project.
- Respond with JSON only. No other text.`;

/**
 * Groups a flat file list into chunks of at most CHUNK_SIZE files.
 * Support files are always placed in the final chunk alongside the last
 * source files, so every chunk has meaningful code to write.
 */
function chunkFiles(files: PlannedFile[]): PlannedFile[][] {
  const sourceFiles = files.filter(f => !f.isSupport);
  const supportFiles = files.filter(f => f.isSupport);

  if (sourceFiles.length === 0) return [supportFiles];

  const chunks: PlannedFile[][] = [];
  for (let i = 0; i < sourceFiles.length; i += CHUNK_SIZE) {
    chunks.push(sourceFiles.slice(i, i + CHUNK_SIZE));
  }

  // Append support files to the last chunk
  chunks[chunks.length - 1].push(...supportFiles);

  return chunks;
}

/**
 * Sends the user message to the model as a planning request.
 * Returns a structured ProjectPlan with files grouped into chunks.
 */
export async function buildPlan(
  userMessage: string,
  conversationHistory: Message[],
  model: string,
  signal: AbortSignal,
): Promise<ProjectPlan> {
  const raw = await chatOnce(
    model,
    [
      ...conversationHistory,
      { role: 'user', content: userMessage },
    ],
    PLANNER_SYSTEM,
    signal,
  );

  // Strip markdown fences if the model wrapped the JSON anyway
  const cleaned = raw
    .replace(/^```(?:json)?\s*/i, '')
    .replace(/\s*```\s*$/, '')
    .trim();

  let parsed: { summary: string; files: PlannedFile[] };
  try {
    parsed = JSON.parse(cleaned);
  } catch {
    // Model returned garbage — fall back to a single-chunk passthrough
    return {
      summary: userMessage,
      files: [],
      chunks: [[]],
      isComplex: false,
    };
  }

  const files: PlannedFile[] = (parsed.files ?? []).map(f => ({
    path: f.path ?? 'unknown',
    description: f.description ?? '',
    isSupport: f.isSupport ?? false,
  }));

  const chunks = chunkFiles(files);

  return {
    summary: parsed.summary ?? '',
    files,
    chunks,
    isComplex: chunks.length > 1,
  };
}

/**
 * Builds the system prompt for a single implementation chunk.
 * Tells the model exactly which files to write in this batch and
 * which files already exist (from previous chunks).
 */
export function buildChunkPrompt(
  baseSystemPrompt: string,
  plan: ProjectPlan,
  chunkIndex: number,
  alreadyWritten: string[],
): string {
  const chunk = plan.chunks[chunkIndex];
  const isLast = chunkIndex === plan.chunks.length - 1;
  const total = plan.chunks.length;

  const fileList = chunk
    .map(f => `  - ${f.path}  →  ${f.description}`)
    .join('\n');

  const writtenList = alreadyWritten.length > 0
    ? `\nAlready written in previous batches (do NOT re-output these):\n${alreadyWritten.map(p => `  - ${p}`).join('\n')}\n`
    : '';

  const batchNote = total > 1
    ? `\nYou are writing batch ${chunkIndex + 1} of ${total} for this project.\n` +
      `Project summary: ${plan.summary}\n` +
      writtenList
    : '';

  return (
    baseSystemPrompt +
    `\n\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
    `YOUR TASK FOR THIS RESPONSE\n` +
    `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
    batchNote +
    `\nWrite ONLY these files (${chunk.length} file${chunk.length !== 1 ? 's' : ''}):\n` +
    fileList +
    `\n\nDo not write any other files. Do not write files from other batches.` +
    (isLast
      ? `\nThis is the final batch — include the changelog and overview after all files.`
      : `\nThis is NOT the final batch — do NOT write a changelog or overview yet.`)
  );
}
